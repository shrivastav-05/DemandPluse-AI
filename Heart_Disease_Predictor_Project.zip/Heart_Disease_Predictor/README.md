# Heart Disease Predictor

## User flow
1. Fill in the heart dataset feature form.
2. Choose **Use Existing Model** or **Train a New Model**.
3. If **Train a New Model** is chosen, select testing size, cross-validation folds, and **Stratified / Non-Stratified** split strategy.
4. Train and evaluate the model, then show the final prediction and metrics.

## Project structure
```text
Heart_Disease_Predictor/
├── app.py
├── Heart_Disease_Predictor.ipynb
├── requirements.txt
├── README.md
├── data/heart.csv
├── models/heart_disease_pipeline.pkl
├── templates/
│   ├── index.html
│   ├── choose_method.html
│   ├── training_configuration.html
│   └── result.html
└── static/heart.css
```

## Run
```powershell
python -m pip install -r requirements.txt
python app.py
```
Then open http://127.0.0.1:5000.

Training configuration includes testing size, CV folds, and split strategy, but no Data Split Preview or information buttons. The result page shows prediction and model evaluation metrics only; it does not show a recommended next step or the phrase "model predicted class".

Educational demonstration only; not for medical diagnosis.
